# Love Wins Media Astro components

Shared, server-rendered components for Love Wins Media sites. The first components extract the AudienceKit-style hero and Love Wins Media attribution band used on Hot Mess. No React dependency, global reset, analytics, product assets or client JavaScript.

Package name: `@lwm-luminx/astro-components`. Requires Astro 7.3.5+ (7.x) and Node 22.23.4+ (CI uses Node 26). Distributed through GitHub Packages.

## Install from GitHub Packages

Add this scope mapping to your consuming project's `.npmrc`:

```ini
@lwm-luminx:registry=https://npm.pkg.github.com
```

Authenticate with a GitHub personal access token (classic) with `read:packages` and access to this private package, then install:

```sh
npm login --scope=@lwm-luminx --auth-type=legacy --registry=https://npm.pkg.github.com
npm install @lwm-luminx/astro-components@0.2.0
```

## Use

```astro
---
import { HeroBanner, BrandBand, BrandCredit, Container, SectionHeading } from '@lwm-luminx/astro-components';
---
<BrandBand />
<HeroBanner
  id="home-title"
  heading="Where your people are tonight."
  eyebrow="Queer nightlife, live"
  description="The venues, events and people of your scene."
  backgroundSrc="/brand/scene-background.webp"
>
  <a href="/download">Get the app</a>
  <img slot="media" src="/screens/app.webp" alt="Tonight in Hot Mess" />
</HeroBanner>
<Container>
  <section aria-labelledby="features-title">
    <SectionHeading id="features-title" title="Find your night." />
  </section>
</Container>
<footer><Container><BrandCredit /></Container></footer>
```

Individual exports are also available, e.g. `@lwm-luminx/astro-components/HeroBanner.astro`.

## Components

| Component | Props | Slots |
| --- | --- | --- |
| `HeroBanner` | Required `id`, `heading`; optional `eyebrow`, `description`, `backgroundSrc`, `backgroundPosition` | Default: actions/supporting text; `media`: decorative or supplementary preview |
| `BrandBand` | `href`, `name`, `newTab` (defaults: lovewins.media, "Love Wins Media", new tab). Renders "A *name* product" with only the name linked, in pink-to-amber gradient text | None |
| `BrandCredit` | `href`, `name`, `legalName`, `newTab` (defaults: lovewins.media, "Love Wins Media", "Love Wins Media, Inc.", new tab). Footer line "A *name* product · © year *legalName*", name linked in pink | None |
| `Container` | Standard div attributes, including `class` and `style` | Content |
| `SectionHeading` | Required `id`, `title`; optional `eyebrow`, `description` | None |

Use one HeroBanner per page: it renders the page's h1. Its background is decorative. Put essential information in the copy/default slot: the media slot hides at widths of 900px and below. Product images and fonts belong to the consuming site. Prefix asset URLs with your site's base path when it is hosted under a subdirectory. Components use scoped CSS; style slotted content in your own site.

## Theme

Set optional CSS custom properties on a parent element:

- `--lwm-font`: font family (inherits by default)
- `--lwm-content-width`: 1080px
- `--lwm-gutter`: 16px
- `--lwm-band-ink`: BrandBand text color (inherits by default)
- `--lwm-band-line`: BrandBand bottom border color

BrandBand and BrandCredit pick their brand colors by `prefers-color-scheme`, so they suit sites whose background follows the system light/dark setting.
- `--lwm-hero-height`: 730px on desktop
- `--lwm-hero-background`, `--lwm-hero-ink`, `--lwm-hero-muted`, `--lwm-hero-accent`
- `--lwm-ink`, `--lwm-muted`, `--lwm-accent` for SectionHeading

The hero intentionally keeps a dark overlay in both color schemes. Check contrast when overriding colors. The attribution band retains its readable pink-to-amber treatment.

## Development

```sh
npm ci
npm run dev     # component playground
npm test        # Astro type-check, consumer build and output checks
npm pack --dry-run
```

CI runs the same checks. Package exports point to Astro source so the consuming Astro build handles compilation; only `src`, package metadata and this README enter the tarball.

## Releases

Publishing a GitHub release with a tag matching the package version (for example, `v0.2.0`) runs the publishing workflow. It installs dependencies, inspects the package contents, and runs `npm publish` against GitHub Packages. The `prepublishOnly` hook runs all tests before upload. Authentication uses the workflow's `GITHUB_TOKEN` with `packages: write`; no separate publishing secret is required.

For subsequent releases, update the version and lockfile with `npm version <patch|minor|major>`, push the commit and tag, and publish a GitHub release for that tag. Package versions are immutable. The package uses `UNLICENSED` and remains proprietary. Never commit npm tokens. Consuming repositories using Actions need package read access and a token with `packages: read`.
